// Selectors
const todoForm = document.getElementById('todo-form');
const todoInput = document.querySelector('.todo-input');
const todoDate = document.querySelector('.todo-date');
const todoTime = document.querySelector('.todo-time');
const todoTag = document.getElementById('todo-tag');
const todoPriority = document.getElementById('todo-priority');
const todoGridContainer = document.querySelector('.todo-grid-container');
const filterTag = document.getElementById('filter-tag');
const filterPriority = document.getElementById('filter-priority');
const filterStatus = document.getElementById('filter-status');
const editModal = document.getElementById('edit-modal');
const editForm = document.getElementById('edit-form');
const editId = document.getElementById('edit-id');
const editText = document.getElementById('edit-text');
const editDate = document.getElementById('edit-date');
const editTime = document.getElementById('edit-time');
const editTag = document.getElementById('edit-tag');
const editPriority = document.getElementById('edit-priority');
const editNotes = document.getElementById('edit-notes');
const closeBtn = document.querySelector('.close');
const cancelBtn = document.querySelector('.cancel-btn');
const standardTheme = document.querySelector('.standard-theme');
const lightTheme = document.querySelector('.light-theme');

// Event Listeners
document.addEventListener('DOMContentLoaded', getTodos);
todoForm.addEventListener('submit', addTodo);
todoGridContainer.addEventListener('click', handleTodoClick);
filterTag.addEventListener('change', filterTodos);
filterPriority.addEventListener('change', filterTodos);
filterStatus.addEventListener('change', filterTodos);
closeBtn.addEventListener('click', closeModal);
cancelBtn.addEventListener('click', closeModal);
editForm.addEventListener('submit', saveEditedTodo);
standardTheme.addEventListener('click', () => changeTheme('standard'));
lightTheme.addEventListener('click', () => changeTheme('light'));

// Check for saved theme
let savedTheme = localStorage.getItem('savedTheme');
if (savedTheme) {
    changeTheme(localStorage.getItem('savedTheme'));
}

// Use the API object from api.js

// Function to get auth token from localStorage
function getAuthToken() {
    return localStorage.getItem('token');
}

// Check if user is logged in
if (!getAuthToken()) {
    // Redirect to login page if not logged in
    window.location.href = '../login/login.html';
}

// Functions
async function addTodo(event) {
    event.preventDefault();

    // Validate input
    if (todoInput.value.trim() === '') {
        showErrorMessage('Please enter a task');
        return;
    }

    // Create todo object
    const todoData = {
        text: todoInput.value.trim(),
        completed: false,
        dueDate: todoDate.value ? new Date(todoDate.value + (todoTime.value ? 'T' + todoTime.value : '')).toISOString() : null,
        tags: todoTag.value ? [todoTag.value] : [],
        priority: parseInt(todoPriority.value) || 1,
        notes: ''
    };

    try {
        // Show loading indicator
        showLoadingMessage('Adding todo...');

        // Call API to create todo
        console.log('Creating todo with data:', todoData);
        await api.post('/todos', todoData);

        // Hide loading indicator
        hideLoadingMessage();

        // Show success message
        showSuccessMessage('Todo added successfully');

        // Render the new todo
        renderTodos();

        // Clear form
        todoForm.reset();
    } catch (error) {
        // Hide loading indicator
        hideLoadingMessage();

        console.error('Error adding todo:', error);
        showErrorMessage('Failed to add todo: ' + (error.message || 'Please try again'));
    }
}

async function getTodos() {
    try {
        // Clear the container
        todoGridContainer.innerHTML = '';

        // Show loading indicator
        todoGridContainer.innerHTML = '<div class="loading">Loading...</div>';

        // Get todos from API
        console.log('Fetching todos from API...');
        const response = await api.get('/todos');
        console.log('API response:', response);
        const todos = response.data;

        // Render todos
        renderTodos(todos);
    } catch (error) {
        console.error('Error getting todos:', error);
        showErrorMessage('Failed to load todos: ' + (error.message || 'Please try again'));

        // Clear loading indicator
        todoGridContainer.innerHTML = '<div class="error">Failed to load todos</div>';
    }
}

function renderTodos(todos = null) {
    // Clear the container
    todoGridContainer.innerHTML = '';

    if (!todos) {
        // If no todos provided, fetch them
        getTodos();
        return;
    }

    // Filter todos based on current filter settings
    const filteredTodos = filterTodosList(todos);

    // Check if there are any todos
    if (filteredTodos.length === 0) {
        todoGridContainer.innerHTML = '<div class="empty-state">No tasks found</div>';
        return;
    }

    // Render each todo
    filteredTodos.forEach(todo => {
        const todoCard = createTodoCard(todo);
        todoGridContainer.appendChild(todoCard);
    });
}

function createTodoCard(todo) {
    // Create card container
    const todoCard = document.createElement('div');
    todoCard.classList.add('todo-card');
    todoCard.dataset.id = todo.id;

    // Add completed class if todo is completed
    if (todo.completed) {
        todoCard.classList.add('completed');
    }

    // Add priority class
    todoCard.classList.add(`priority-${todo.priority}`);

    // Create card content
    const dueDate = todo.dueDate ? new Date(todo.dueDate) : null;
    const formattedDate = dueDate ? dueDate.toLocaleDateString() : '';
    const formattedTime = dueDate ? dueDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '';

    // Format tags with proper styling
    let tagsHtml = '';
    if (todo.tags && todo.tags.length > 0) {
        tagsHtml = todo.tags.map(tag => `<span class="todo-tag ${tag}">${tag}</span>`).join('');
    }

    todoCard.innerHTML = `
        <div class="todo-content">
            <h3 class="todo-text">${todo.text}</h3>
            ${dueDate ? `<p class="todo-date-time">${formattedDate} ${formattedTime}</p>` : ''}
            <div class="todo-tags">${tagsHtml}</div>
            <p class="todo-priority">Priority: ${['Low', 'Medium', 'High'][todo.priority - 1]}</p>
            ${todo.notes ? `<p class="todo-notes">${todo.notes}</p>` : ''}
        </div>
        <div class="todo-actions">
            <button class="complete-btn ${todo.completed ? 'completed' : ''}" title="Mark as ${todo.completed ? 'incomplete' : 'complete'}">
                <i class="fas fa-check"></i>
            </button>
            <button class="edit-btn" title="Edit task">
                <i class="fas fa-edit"></i>
            </button>
            <button class="delete-btn" title="Delete task">
                <i class="fas fa-trash"></i>
            </button>
        </div>
    `;

    return todoCard;
}

async function handleTodoClick(event) {
    const item = event.target;
    const todoCard = item.closest('.todo-card');

    if (!todoCard) return;

    const todoId = todoCard.dataset.id;

    // Check which button was clicked
    if (item.closest('.complete-btn')) {
        toggleComplete(todoId);
    } else if (item.closest('.delete-btn')) {
        deleteTodo(todoId);
    } else if (item.closest('.edit-btn')) {
        // Get todo data from the card
        const todoText = todoCard.querySelector('.todo-text').textContent;
        const todoDateTimeText = todoCard.querySelector('.todo-date-time')?.textContent || '';
        const todoTagText = todoCard.querySelector('.todo-tag')?.textContent || '';
        const todoPriorityText = todoCard.querySelector('.todo-priority').textContent;

        // Parse date and time
        let todoDateTime = todoDateTimeText.trim().split(' ');
        let todoDateValue = '';
        let todoTimeValue = '';

        if (todoDateTime.length >= 1) {
            const dateParts = todoDateTime[0].split('/');
            if (dateParts.length === 3) {
                todoDateValue = `${dateParts[2]}-${dateParts[0].padStart(2, '0')}-${dateParts[1].padStart(2, '0')}`;
            }
        }

        if (todoDateTime.length >= 2) {
            todoTimeValue = todoDateTime[1];
        }

        // Parse priority
        let todoPriorityValue = 1;
        if (todoPriorityText.includes('Medium')) {
            todoPriorityValue = 2;
        } else if (todoPriorityText.includes('High')) {
            todoPriorityValue = 3;
        }

        // Show loading indicator
        showLoadingMessage('Loading todo details...');

        // Get the full todo object from the API
        try {
            const response = await api.get(`/todos/${todoId}`);
            const todo = response.data;

            // Hide loading indicator
            hideLoadingMessage();

            // Open edit modal with todo data
            openEditModal({
                id: todoId,
                text: todoText,
                date: todoDateValue,
                time: todoTimeValue,
                tag: todo.tags && todo.tags.length > 0 ? todo.tags[0] : '',
                priority: todoPriorityValue,
                notes: todo.notes || ''
            });
        } catch (error) {
            // Hide loading indicator
            hideLoadingMessage();

            console.error('Error getting todo details:', error);
            showErrorMessage('Failed to get todo details: ' + (error.message || 'Please try again'));

            // Fallback to using the data from the card
            openEditModal({
                id: todoId,
                text: todoText,
                date: todoDateValue,
                time: todoTimeValue,
                tag: todoTagText,
                priority: todoPriorityValue,
                notes: ''
            });
        }
    }
}

async function toggleComplete(id) {
    try {
        const todoCard = document.querySelector(`.todo-card[data-id="${id}"]`);
        const isCompleted = todoCard.classList.contains('completed');

        // Toggle completed status in UI
        todoCard.classList.toggle('completed');
        todoCard.querySelector('.complete-btn').classList.toggle('completed');

        // Show loading indicator
        showLoadingMessage('Updating todo status...');

        // Update in API
        await api.put(`/todos/${id}`, { completed: !isCompleted });

        // Hide loading indicator
        hideLoadingMessage();

        // Show success message
        showSuccessMessage('Todo status updated');
    } catch (error) {
        // Hide loading indicator
        hideLoadingMessage();

        console.error('Error toggling todo completion:', error);
        showErrorMessage('Failed to update todo status: ' + (error.message || 'Please try again'));

        // Revert UI change
        const todoCard = document.querySelector(`.todo-card[data-id="${id}"]`);
        todoCard.classList.toggle('completed');
        todoCard.querySelector('.complete-btn').classList.toggle('completed');
    }
}

async function deleteTodo(id) {
    try {
        // Show confirmation dialog
        if (!confirm('Are you sure you want to delete this task?')) {
            return;
        }

        // Remove from UI
        const todoCard = document.querySelector(`.todo-card[data-id="${id}"]`);
        todoCard.classList.add('fall');

        // Show loading indicator
        showLoadingMessage('Deleting todo...');

        // Wait for animation to complete
        todoCard.addEventListener('transitionend', async function() {
            try {
                // Delete from API
                await api.delete(`/todos/${id}`);

                // Hide loading indicator
                hideLoadingMessage();

                // Show success message
                showSuccessMessage('Todo deleted successfully');

                todoCard.remove();
            } catch (error) {
                // Hide loading indicator
                hideLoadingMessage();

                console.error('Error deleting todo:', error);
                showErrorMessage('Failed to delete todo: ' + (error.message || 'Please try again'));

                // Revert UI change
                todoCard.classList.remove('fall');
            }
        });
    } catch (error) {
        // Hide loading indicator
        hideLoadingMessage();

        console.error('Error deleting todo:', error);
        showErrorMessage('Failed to delete todo: ' + (error.message || 'Please try again'));
    }
}

function openEditModal(todo) {
    // Populate form fields
    editId.value = todo.id;
    editText.value = todo.text;
    editDate.value = todo.date;
    editTime.value = todo.time;
    editTag.value = todo.tag;
    editPriority.value = todo.priority;
    editNotes.value = todo.notes;

    // Show modal
    editModal.style.display = 'block';
}

function closeModal() {
    editModal.style.display = 'none';
}

async function saveEditedTodo(event) {
    event.preventDefault();

    // Validate input
    if (editText.value.trim() === '') {
        showErrorMessage('Please enter a task');
        return;
    }

    const id = editId.value;

    // Create updated todo object
    const todoData = {
        text: editText.value.trim(),
        dueDate: editDate.value ? new Date(editDate.value + (editTime.value ? 'T' + editTime.value : '')).toISOString() : null,
        tags: editTag.value ? [editTag.value] : [],
        priority: parseInt(editPriority.value) || 1,
        notes: editNotes.value
    };

    try {
        // Show loading indicator
        showLoadingMessage('Updating todo...');

        // Update todo in API
        await api.put(`/todos/${id}`, todoData);

        // Hide loading indicator
        hideLoadingMessage();

        // Show success message
        showSuccessMessage('Todo updated successfully');

        // Close modal
        closeModal();

        // Refresh todos
        getTodos();
    } catch (error) {
        // Hide loading indicator
        hideLoadingMessage();

        console.error('Error updating todo:', error);
        showErrorMessage('Failed to update todo: ' + (error.message || 'Please try again'));
    }
}

function filterTodos() {
    // Refresh todos with current filters
    getTodos();
}

function filterTodosList(todos) {
    // Get filter values
    const tagFilter = filterTag.value;
    const priorityFilter = parseInt(filterPriority.value);
    const statusFilter = filterStatus.value;

    // Apply filters
    return todos.filter(todo => {
        // Tag filter
        if (tagFilter && (!todo.tags || !todo.tags.includes(tagFilter))) {
            return false;
        }

        // Priority filter
        if (priorityFilter && todo.priority !== priorityFilter) {
            return false;
        }

        // Status filter
        if (statusFilter === 'completed' && !todo.completed) {
            return false;
        } else if (statusFilter === 'active' && todo.completed) {
            return false;
        }

        return true;
    });
}

function showErrorMessage(message) {
    // Create error message element
    const errorMessage = document.createElement('div');
    errorMessage.classList.add('error-message');
    errorMessage.textContent = message;

    // Add to page
    document.body.appendChild(errorMessage);

    // Remove after 3 seconds
    setTimeout(() => {
        errorMessage.classList.add('fade-out');
        errorMessage.addEventListener('transitionend', () => {
            errorMessage.remove();
        });
    }, 3000);
}

function showSuccessMessage(message) {
    // Create success message element
    const successMessage = document.createElement('div');
    successMessage.classList.add('success-message');
    successMessage.textContent = message;

    // Add to page
    document.body.appendChild(successMessage);

    // Remove after 3 seconds
    setTimeout(() => {
        successMessage.classList.add('fade-out');
        successMessage.addEventListener('transitionend', () => {
            successMessage.remove();
        });
    }, 3000);
}

function showLoadingMessage(message) {
    // Remove any existing loading messages
    hideLoadingMessage();

    // Create loading message element
    const loadingMessage = document.createElement('div');
    loadingMessage.classList.add('loading-message');
    loadingMessage.textContent = message;

    // Add to page
    document.body.appendChild(loadingMessage);
}

function hideLoadingMessage() {
    // Remove any existing loading messages
    const existingLoadingMessages = document.querySelectorAll('.loading-message');
    existingLoadingMessages.forEach(message => {
        message.remove();
    });
}



// Change theme function
function changeTheme(color) {
    document.body.className = color;
    localStorage.setItem('savedTheme', color);
    savedTheme = localStorage.getItem('savedTheme');
}

// Close modal when clicking outside
window.onclick = function(event) {
    if (event.target === editModal) {
        closeModal();
    }
};
